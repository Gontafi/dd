package main

import "doodocs-archive/internal/app"

func main() {
	app.RunApp()
}
